import { getSupabase, isValidUuid, isUniqueViolation } from './_lib/supabase.js';
import { rateLimitCheck } from './_lib/rateLimit.js'
import { requirePermission } from './_lib/auth.js';
import { cors } from './_lib/cors.js';
import { logActivity } from './notifications.js';

const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

const LINK_FIELDS = new Set(['slug', 'target', 'label', 'active']);

function sanitizeLinkUpdate(value) {
  const clean = Object.fromEntries(Object.entries(value || {}).filter(([key]) => LINK_FIELDS.has(key)));
  if (clean.slug !== undefined) {
    if (typeof clean.slug !== 'string' || clean.slug.length > 40 || !SLUG_RE.test(clean.slug)) return null;
  }
  if (clean.target !== undefined) {
    if (typeof clean.target !== 'string' || !/^https?:\/\//i.test(clean.target)) return null;
    clean.target = clean.target.trim().slice(0, 2000);
  }
  if (clean.label !== undefined) clean.label = String(clean.label).trim().slice(0, 100);
  if (clean.active !== undefined) clean.active = Boolean(clean.active);
  return clean;
}

function rowToLink(row) {
  if (!row) return row;
  return {
    _id: row.id,
    id: row.id,
    slug: row.slug,
    target: row.target,
    label: row.label,
    active: row.active,
    clicks: row.clicks,
    lastClickAt: row.last_click_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export default async function handler(req, res) {
  /* Public okuma yolu: kimlik doğrulaması yok, her istek DB'ye gidiyor ve
     handle/slug numaralandırılabilir. Cömert limit + failOpen: Redis kesintisi
     public profil sayfalarını düşürmemeli. */
  const rl = await rateLimitCheck(req, { namespace: 'short-links', maxRequests: 240, failOpen: true })
  if (!rl.allowed) return res.status(429).json({ error: 'Çok fazla istek' })

  if (cors(req, res)) return;

  const supabase = getSupabase();

  // GET - public resolve by slug, or admin list of all short links
  if (req.method === 'GET') {
    try {
      const slug = req.query?.slug;
      if (slug) {
        if (typeof slug !== 'string' || !SLUG_RE.test(slug)) return res.status(400).json({ error: 'Geçersiz slug' });
        const { data: link, error } = await supabase.from('kade_short_links').select('slug, target').eq('slug', slug).eq('active', true).maybeSingle();
        if (error) throw error;
        if (!link) return res.status(404).json({ error: 'Link bulunamadı' });
        return res.status(200).json({ slug: link.slug, target: link.target });
      }

      const user = await requirePermission(req, res, 'shortLinks');
      if (!user) return;
      const { data, error } = await supabase.from('kade_short_links').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data.map(rowToLink));
    } catch (error) {
      console.error('ShortLinks GET error:', error);
      return res.status(500).json({ error: 'Sunucu hatası' });
    }
  }

  // POST - create link, or record a click (?action=click, public)
  if (req.method === 'POST') {
    if (req.query?.action === 'click') {
      try {
        const slug = req.body?.slug;
        if (typeof slug !== 'string' || !SLUG_RE.test(slug)) return res.status(400).json({ error: 'Geçersiz slug' });

        const { data: existing, error: findError } = await supabase.from('kade_short_links').select('id, clicks').eq('slug', slug).maybeSingle();
        if (findError) throw findError;
        if (existing) {
          const { error: updError } = await supabase
            .from('kade_short_links')
            .update({ clicks: (existing.clicks || 0) + 1, last_click_at: new Date().toISOString() })
            .eq('id', existing.id);
          if (updError) throw updError;
        }
        return res.status(204).end();
      } catch (error) {
        console.error('ShortLinks click error:', error);
        return res.status(500).json({ error: 'Sunucu hatası' });
      }
    }

    const user = await requirePermission(req, res, 'shortLinks', { write: true });
    if (!user) return;

    try {
      const clean = sanitizeLinkUpdate(req.body);
      if (!clean) return res.status(400).json({ error: 'Link verisi geçersiz' });
      if (!clean.slug) return res.status(400).json({ error: 'Slug gerekli' });
      if (!clean.target) return res.status(400).json({ error: 'Hedef URL gerekli' });

      const { data: existing, error: existingError } = await supabase.from('kade_short_links').select('id').eq('slug', clean.slug).maybeSingle();
      if (existingError) throw existingError;
      if (existing) return res.status(409).json({ error: 'Bu slug zaten kullanılıyor' });

      const row = {
        slug: clean.slug,
        target: clean.target,
        label: clean.label || '',
        active: clean.active !== false,
        clicks: 0,
      };
      const { data, error } = await supabase.from('kade_short_links').insert(row).select().single();
      if (error) {
        if (isUniqueViolation(error)) return res.status(409).json({ error: 'Bu slug zaten kullanılıyor' });
        throw error;
      }
      await logActivity({ action: 'Kısa link oluşturuldu', detail: data.slug, type: 'create', icon: '🔗', user: user.username }).catch(() => {});
      return res.status(201).json(rowToLink(data));
    } catch (error) {
      console.error('ShortLinks POST error:', error);
      return res.status(500).json({ error: 'Sunucu hatası' });
    }
  }

  // PUT - Update link (requires auth)
  if (req.method === 'PUT') {
    const user = await requirePermission(req, res, 'shortLinks', { write: true });
    if (!user) return;

    try {
      const { _id, ...rawUpdateData } = req.body || {};
      if (!_id) return res.status(400).json({ error: 'Link ID gerekli' });
      if (!isValidUuid(_id)) return res.status(400).json({ error: 'Geçersiz ID' });

      const updateData = sanitizeLinkUpdate(rawUpdateData);
      if (!updateData) return res.status(400).json({ error: 'Link verisi geçersiz' });

      if (updateData.slug) {
        const { data: clash, error: clashError } = await supabase.from('kade_short_links').select('id').eq('slug', updateData.slug).neq('id', _id).maybeSingle();
        if (clashError) throw clashError;
        if (clash) return res.status(409).json({ error: 'Bu slug zaten kullanılıyor' });
      }

      const row = { ...updateData, updated_at: new Date().toISOString() };
      const { data, error } = await supabase.from('kade_short_links').update(row).eq('id', _id).select('id');
      if (error) {
        if (isUniqueViolation(error)) return res.status(409).json({ error: 'Bu slug zaten kullanılıyor' });
        throw error;
      }
      if (!data || data.length === 0) return res.status(404).json({ error: 'Link bulunamadı' });

      await logActivity({ action: 'Kısa link güncellendi', detail: updateData.slug || _id, type: 'update', icon: '✏️', user: user.username }).catch(() => {});
      return res.status(200).json({ message: 'Link güncellendi' });
    } catch (error) {
      console.error('ShortLinks PUT error:', error);
      return res.status(500).json({ error: 'Sunucu hatası' });
    }
  }

  // DELETE - Delete link (requires auth)
  if (req.method === 'DELETE') {
    const user = await requirePermission(req, res, 'shortLinks', { write: true });
    if (!user) return;

    try {
      const queryId = req.body?.id || req.query.id;
      if (!queryId) return res.status(400).json({ error: 'Link ID gerekli' });
      if (!isValidUuid(queryId)) return res.status(400).json({ error: 'Geçersiz ID' });

      const { data: link, error: findError } = await supabase.from('kade_short_links').select('slug').eq('id', queryId).maybeSingle();
      if (findError) throw findError;

      const { data, error } = await supabase.from('kade_short_links').delete().eq('id', queryId).select('id');
      if (error) throw error;
      if (!data || data.length === 0) return res.status(404).json({ error: 'Link bulunamadı' });

      await logActivity({ action: 'Kısa link silindi', detail: link?.slug || queryId, type: 'delete', icon: '🗑️', user: user.username }).catch(() => {});
      return res.status(200).json({ message: 'Link silindi' });
    } catch (error) {
      console.error('ShortLinks DELETE error:', error);
      return res.status(500).json({ error: 'Sunucu hatası' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
