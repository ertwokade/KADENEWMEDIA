import nodemailer from 'nodemailer';
import crypto from 'crypto';
import { getSupabase, isValidUuid, isUniqueViolation } from './_lib/supabase.js';
import { cors } from './_lib/cors.js';
import { rateLimitCheck } from './_lib/rateLimit.js';
import { requireAdmin, requirePermission } from './_lib/auth.js';
import { sanitizeNewsletterHtml } from './_lib/sanitize.js';
import { logActivity } from './notifications.js';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function getUnsubSecret() {
  return process.env.UNSUBSCRIBE_SECRET || process.env.JWT_SECRET;
}

function generateUnsubToken(email) {
  const secret = getUnsubSecret();
  if (!secret) return null;
  return crypto.createHmac('sha256', secret).update(email.toLowerCase()).digest('hex');
}

function verifyUnsubToken(email, token) {
  if (typeof token !== 'string' || !/^[a-f0-9]{64}$/.test(token)) return false;
  const expected = generateUnsubToken(email);
  if (!expected) return false;
  try {
    return crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(token, 'hex'));
  } catch { return false; }
}

function escapeHtml(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function cleanHeader(str, max = 200) {
  return String(str || '').replace(/[\r\n]+/g, ' ').trim().slice(0, max);
}

function makeTransporter() {
  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT) || 587;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  if (!host || !user || !pass) return null;
  return nodemailer.createTransport({
    host, port, secure: port === 465,
    auth: { user, pass },
    ...(port === 587 ? { requireTLS: true } : {}),
    tls: { rejectUnauthorized: true, minVersion: 'TLSv1.2' },
    connectionTimeout: 10000, greetingTimeout: 10000, socketTimeout: 15000,
  });
}

export default async function handler(req, res) {
  if (cors(req, res)) return;

  const action = req.query?.action;

  // ── Newsletter aboneleri (auth gerekli) ──
  if (action === 'subscribers') {
    const user = await requirePermission(req, res, 'messages', { write: req.method !== 'GET' });
    if (!user) return;
    const supabase = getSupabase();

    if (req.method === 'GET') {
      try {
        const { data: subscribers, error } = await supabase
          .from('kade_newsletter')
          .select('*')
          .order('created_at', { ascending: false });
        if (error) throw error;
        return res.status(200).json(subscribers);
      } catch (err) {
        return res.status(500).json({ error: 'Sunucu hatası' });
      }
    }

    if (req.method === 'DELETE') {
      try {
        const id = req.query?.id;
        if (!id) return res.status(400).json({ error: 'id gerekli' });
        if (!isValidUuid(id)) return res.status(400).json({ error: 'Geçersiz ID' });
        const { error } = await supabase.from('kade_newsletter').delete().eq('id', id);
        if (error) throw error;
        await logActivity({ action: 'Newsletter abonesi silindi', detail: '', type: 'delete', icon: '📧', user: user.username }).catch(() => {});
        return res.status(200).json({ success: true });
      } catch (err) {
        return res.status(500).json({ error: 'Sunucu hatası' });
      }
    }
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // ── Newsletter toplu gönderme (auth gerekli) ──
  if (action === 'send-newsletter') {
    const user = await requirePermission(req, res, 'messages', { write: true });
    if (!user) return;
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    let body = req.body;
    if (typeof body === 'string') { try { body = JSON.parse(body); } catch { body = {}; } }

    const { subject, html } = body || {};
    if (!subject?.trim()) return res.status(400).json({ error: 'Konu gerekli' });
    if (!html?.trim()) return res.status(400).json({ error: 'İçerik gerekli' });
    if (subject.length > 200) return res.status(400).json({ error: 'Konu çok uzun (max 200)' });
    if (html.length > 100000) return res.status(400).json({ error: 'İçerik çok uzun' });
    const sanitizedHtml = sanitizeNewsletterHtml(html);
    if (!sanitizedHtml.trim()) return res.status(400).json({ error: 'Newsletter HTML guvenli icerik icermiyor' });

    const transporter = makeTransporter();
    if (!transporter) return res.status(400).json({ error: 'SMTP yapılandırılmamış' });

    try {
      const supabase = getSupabase();
      const { data: subscribers, error } = await supabase.from('kade_newsletter').select('*').neq('status', 'unsubscribed');
      if (error) throw error;
      if (subscribers.length === 0) return res.status(200).json({ sent: 0, message: 'Abone bulunamadı' });

      let sent = 0;
      const errors = [];

      for (const sub of subscribers) {
        try {
          const unsubToken = generateUnsubToken(sub.email);
          const unsubLink = `https://kadenewmedia.com/api/contact?action=unsubscribe&email=${encodeURIComponent(sub.email)}${unsubToken ? `&token=${unsubToken}` : ''}`;
          const safeHtml = sanitizedHtml + `<div style="margin-top:32px;padding-top:16px;border-top:1px solid #333;text-align:center;font-size:12px;color:#888;">
            <a href="${unsubLink}" style="color:#888;">Abonelikten çık</a>
          </div>`;
          await transporter.sendMail({
            from: `"Kade New Media" <${process.env.SMTP_USER}>`,
            to: sub.email,
            subject: escapeHtml(subject),
            html: safeHtml,
          });
          sent++;
        } catch (err) {
          errors.push(sub.email);
        }
      }

      await logActivity({ action: 'Newsletter gönderildi', detail: `${sent} aboneye: "${subject}"`, type: 'create', icon: '📧', user: user.username }).catch(() => {});
      return res.status(200).json({ sent, total: subscribers.length, ...(errors.length ? { errors } : {}) });
    } catch (err) {
      return res.status(500).json({ error: 'Sunucu hatası' });
    }
  }

  // ── SMTP test (auth gerekli) ──
  if (action === 'smtp-test') {
    if (!(await requireAdmin(req, res))) return;
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const transporter = makeTransporter();
    if (!transporter) return res.status(400).json({ error: 'SMTP ayarları yapılandırılmamış (SMTP_HOST, SMTP_USER, SMTP_PASS gerekli)' });

    try {
      await transporter.verify();
      return res.status(200).json({ success: true, message: 'SMTP bağlantısı başarılı!' });
    } catch (err) {
      return res.status(200).json({ success: false, message: 'SMTP bağlantı hatası. Ayarları kontrol edin.' });
    }
  }

  if (action === 'apply' || action === 'analyzer-lead') {
    return res.status(410).json({ error: 'Bu form artık kullanılmıyor.' });
  }

  // ── Abonelik iptali (GET, imzalı token gerekli) ──
  if (action === 'unsubscribe') {
    const email = Array.isArray(req.query?.email) ? req.query.email[0] : req.query?.email;
    const token = Array.isArray(req.query?.token) ? req.query.token[0] : req.query?.token;
    if (!email || !EMAIL_RE.test(email)) {
      return res.status(400).send('<html><body style="font-family:Arial;text-align:center;padding:60px;background:#0a0a0a;color:#fff"><h2>Geçersiz e-posta adresi.</h2></body></html>');
    }
    if (!verifyUnsubToken(email, token)) {
      return res.status(403).send('<html><body style="font-family:Arial;text-align:center;padding:60px;background:#0a0a0a;color:#fff"><h2>Geçersiz veya süresi dolmuş abonelik iptal bağlantısı.</h2></body></html>');
    }
    try {
      const supabase = getSupabase();
      const { error } = await supabase
        .from('kade_newsletter')
        .update({ status: 'unsubscribed', unsubscribed_at: new Date().toISOString() })
        .eq('email', email.toLowerCase());
      if (error) throw error;
      return res.status(200).send('<html><body style="font-family:Arial;text-align:center;padding:60px;background:#0a0a0a;color:#fff"><h2 style="color:#eac321">Aboneliğiniz iptal edildi.</h2><p style="color:#888">Kade New Media bülteninden başarıyla çıktınız.</p></body></html>');
    } catch {
      return res.status(500).send('<html><body style="font-family:Arial;text-align:center;padding:60px;background:#0a0a0a;color:#fff"><h2>Bir hata oluştu, lütfen tekrar deneyin.</h2></body></html>');
    }
  }

  // ── Newsletter aboneliği (public, POST only) ──
  if (action === 'newsletter') {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
    const nlRl = await rateLimitCheck(req, { namespace: 'newsletter-subscribe', maxRequests: 10 });
    if (!nlRl.allowed) return res.status(429).json({ error: `Çok fazla istek. ${nlRl.retryAfter} dakika sonra tekrar deneyin.` });
    return handleNewsletter(req, res);
  }

  // ── Normal contact form (POST only) ──
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Rate limiting
  const rl = await rateLimitCheck(req, { namespace: 'contact', maxRequests: 5 });
  if (!rl.allowed) {
    return res.status(429).json({
      error: `Çok fazla istek. Lütfen ${rl.retryAfter} dakika sonra tekrar deneyin.`,
    });
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch { body = {}; }
  }

  const {
    name, email, phone, company, service, message, consent, website,
  } = body || {};

  // Honeypot. `website` alanı formda gizli ve boş; yalnız otomatik doldurucular
  // yazar. İstemci tarafında da kontrol ediliyor ama oradaki kontrol doğrudan
  // API'ye POST atan botu elemiyor. Bot'a başarısız olduğu söylenmez —
  // aksi hâlde alanı boş bırakmayı öğrenir; istek sessizce yutulur.
  if (typeof website === 'string' && website.trim()) {
    return res.status(200).json({ message: 'Mesajınız başarıyla gönderildi!' });
  }

  if (!name?.trim() || !email?.trim() || !message?.trim()) {
    return res.status(400).json({ error: 'Ad, e-posta ve mesaj alanları zorunludur.' });
  }
  if (consent !== true) return res.status(400).json({ error: 'Aydınlatma metni onayı gereklidir.' });

  if (name.trim().length > 100) return res.status(400).json({ error: 'Ad çok uzun (max 100 karakter).' });
  if (email.trim().length > 254) return res.status(400).json({ error: 'E-posta çok uzun.' });
  if (phone && phone.length > 30) return res.status(400).json({ error: 'Telefon çok uzun.' });
  if (company && company.length > 100) return res.status(400).json({ error: 'Şirket adı çok uzun.' });
  if (service && (typeof service !== 'string' || service.length > 200)) return res.status(400).json({ error: 'Hizmet seçimi geçersiz.' });
  if (message.trim().length > 5000) return res.status(400).json({ error: 'Mesaj çok uzun (max 5000 karakter).' });

  if (!EMAIL_RE.test(email)) {
    return res.status(400).json({ error: 'Geçerli bir e-posta adresi giriniz.' });
  }

  if (message.trim().length < 20) {
    return res.status(400).json({ error: 'Mesajınız en az 20 karakter olmalıdır.' });
  }

  try {
    let persisted = false;
    let notified = false;
    // Save to DB
    try {
      const supabase = getSupabase();
      const { error: insertError } = await supabase.from('kade_messages').insert({
        name: name.trim(),
        email: email.trim().toLowerCase(),
        phone: phone?.trim() || '-',
        company: company?.trim() || '-',
        service: service || '-',
        message: message.trim(),
        source: 'iletisim-formu',
        consent_at: new Date().toISOString(),
        status: 'yeni',
        read: false,
      });
      if (insertError) throw insertError;
      persisted = true;
      await logActivity({ action: 'Yeni mesaj alındı', detail: `${name.trim()} - ${service || 'Genel'}`, type: 'message', icon: '✉️', user: 'sistem' }).catch(() => {});
    } catch (dbErr) {
      console.error('Supabase save failed (non-critical):', dbErr.message);
    }

    // Send notification email to team
    const mailTo = process.env.MAIL_TO || 'thekademedia@gmail.com';
    const transporter = makeTransporter();

    if (transporter) {
      try {
        await transporter.sendMail({
          from: `"Kade New Media Website" <${process.env.SMTP_USER}>`,
          to: mailTo,
          subject: cleanHeader(`🔔 Yeni Lead: ${name} — ${service || 'Genel'}`),
          html: `
            <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;background:#0a0a0a;color:#fff;border-radius:12px;">
              <div style="text-align:center;padding:20px 0;border-bottom:1px solid #333;">
                <h1 style="color:#eac321;margin:0;">⚡ Kade New Media</h1>
                <p style="color:#888;margin:8px 0 0">Yeni Lead Bildirimi</p>
              </div>
              <div style="padding:30px 20px;">
                <table style="width:100%;border-collapse:collapse;">
                  <tr><td style="padding:8px 0;color:#888;width:120px;">Ad Soyad</td><td style="padding:8px 0;color:#fff;font-weight:600;">${escapeHtml(name)}</td></tr>
                  <tr><td style="padding:8px 0;color:#888;">E-posta</td><td style="padding:8px 0;color:#eac321;">${escapeHtml(email)}</td></tr>
                  <tr><td style="padding:8px 0;color:#888;">Telefon</td><td style="padding:8px 0;color:#fff;">${escapeHtml(phone || '-')}</td></tr>
                  <tr><td style="padding:8px 0;color:#888;">Şirket</td><td style="padding:8px 0;color:#fff;">${escapeHtml(company || '-')}</td></tr>
                  <tr><td style="padding:8px 0;color:#888;">Hizmet</td><td style="padding:8px 0;color:#fff;">${escapeHtml(service || '-')}</td></tr>
                </table>
                <div style="margin-top:20px;padding:16px;background:#1a1a1a;border-radius:8px;border-left:3px solid #eac321;">
                  <p style="color:#ccc;margin:0;line-height:1.6;">${escapeHtml(message)}</p>
                </div>
                <div style="text-align:center;margin:24px 0;">
                  <a href="mailto:${escapeHtml(email)}" style="display:inline-block;padding:14px 32px;background:#eac321;color:#000;text-decoration:none;border-radius:8px;font-weight:bold;">Yanıtla</a>
                </div>
              </div>
            </div>
          `,
        });
        notified = true;
      } catch (mailErr) {
        console.log('Team notification email failed (non-critical):', mailErr.message);
      }

      // Thank you email
      try {
        await transporter.sendMail({
          from: `"Kade New Media" <${process.env.SMTP_USER}>`,
          to: email,
          subject: 'Mesajınız Alındı — Kade New Media',
          html: `
            <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;background:#1a1a2e;color:#fff;border-radius:12px;">
              <div style="text-align:center;padding:20px 0;border-bottom:1px solid #333;">
                <h1 style="color:#eac321;margin:0;">Kade New Media</h1>
              </div>
              <div style="padding:30px 20px;">
                <h2 style="color:#fff;">Merhaba ${escapeHtml(name)},</h2>
                <p style="color:#ccc;line-height:1.8;">Mesajınız başarıyla alındı. Talebiniz incelendikten sonra verdiğiniz iletişim bilgileri üzerinden yanıtlanacaktır.</p>
                <p style="color:#ccc;line-height:1.8;">Ek bilgi paylaşmak için bu e-postayı yanıtlayabilirsiniz.</p>
                <hr style="border:none;border-top:1px solid #333;margin:24px 0;" />
                <p style="color:#888;font-size:13px;">Kade New Media | İstanbul<br/>thekademedia@gmail.com</p>
              </div>
            </div>
          `,
        });
      } catch (thankYouErr) {
        console.log('Thank-you email failed (non-critical):', thankYouErr.message);
      }
    }

    // WhatsApp notification
    const waPhone = process.env.WA_PHONE;
    const waApiKey = process.env.WA_APIKEY;
    if (waPhone && waApiKey) {
      try {
        const waText = encodeURIComponent(
          `🔔 Yeni Lead!\n👤 ${name}\n📧 ${email}\n📞 ${phone || '-'}\n🏢 ${company || '-'}\n🎯 ${service || '-'}\n💬 ${message.substring(0, 100)}${message.length > 100 ? '...' : ''}`
        );
        await fetch(`https://api.callmebot.com/whatsapp.php?phone=${waPhone}&text=${waText}&apikey=${waApiKey}`);
      } catch (waError) {
        console.log('WA notification failed (non-critical):', waError.message);
      }
    }

    if (!persisted && !notified) {
      return res.status(503).json({ error: 'Mesaj şu anda kaydedilemedi. Lütfen e-posta ile iletişime geçin.' });
    }
    return res.status(200).json({ message: 'Mesajınız başarıyla gönderildi!' });
  } catch (error) {
    console.error('Contact error:', error);
    return res.status(500).json({ error: 'Mesaj gönderilirken bir hata oluştu' });
  }
}

// ========== NEWSLETTER HANDLER ==========
async function handleNewsletter(req, res) {
  const { email } = req.body || {};
  if (!email || !EMAIL_RE.test(email)) {
    return res.status(400).json({ error: 'Geçerli bir e-posta adresi giriniz.' });
  }
  try {
    const supabase = getSupabase();
    const { error } = await supabase.from('kade_newsletter').insert({
      email: email.toLowerCase(),
      status: 'active',
      source: 'website',
    });
    if (error) {
      if (isUniqueViolation(error)) {
        return res.status(200).json({ message: 'Bu e-posta zaten kayıtlı.' });
      }
      throw error;
    }
    return res.status(200).json({ message: 'Aboneliğiniz başarıyla oluşturuldu!' });
  } catch (err) {
    console.error('Newsletter error:', err);
    return res.status(500).json({ error: 'Bir hata oluştu, lütfen tekrar deneyin.' });
  }
}
